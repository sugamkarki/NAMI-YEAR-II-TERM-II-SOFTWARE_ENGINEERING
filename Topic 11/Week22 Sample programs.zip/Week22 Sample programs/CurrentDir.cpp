// This program lets the user enter a filename.
#include <iostream>
#include <string>
#include <fstream>
#include <stdio.h>  /* defines FILENAME_MAX */

#include <direct.h>
#define GetCurrentDir _getcwd

using namespace std;

int main()
{
   char cCurrentPath[FILENAME_MAX];

   if (!GetCurrentDir(cCurrentPath, sizeof(cCurrentPath)))
     {
     return errno;
     }

 //cCurrentPath[sizeof(cCurrentPath) - 1] = '\0'; /* not really required */
 cout << "The current working directory is " << cCurrentPath;
 system("PAUSE");
 return 0;

}