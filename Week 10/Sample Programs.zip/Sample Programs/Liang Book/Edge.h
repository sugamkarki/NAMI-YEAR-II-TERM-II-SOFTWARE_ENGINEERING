#ifndef EDGE_H
#define EDGE_H

class Edge
{
public:
  int u;
  int v;

  Edge(int u, int v)
  {
    this->u = u;
    this->v = v;
  }
};
#endif
